import { users, type User, type InsertUser } from "@shared/schema";
import { feedback, type Feedback, type InsertFeedback } from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, and, or } from "drizzle-orm";
import { sql } from "drizzle-orm";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createFeedback(feedback: InsertFeedback): Promise<Feedback>;
  getFeedback(
    category: string,
    sortBy: string,
    page: number,
    limit: number
  ): Promise<{
    feedbacks: Feedback[];
    totalCount: number;
    pageCount: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async createFeedback(insertFeedback: InsertFeedback): Promise<Feedback> {
    const [result] = await db.insert(feedback).values(insertFeedback).returning();
    return result;
  }

  async getFeedback(
    category: string,
    sortBy: string,
    page: number,
    limit: number
  ): Promise<{
    feedbacks: Feedback[];
    totalCount: number;
    pageCount: number;
  }> {
    // Build query
    let query = db.select().from(feedback);
    
    // Apply category filter if not 'all'
    if (category !== "all") {
      query = query.where(eq(feedback.category, category));
    }
    
    // Count total records
    let countResult = await db.select({ count: sql`count(*)` }).from(feedback);
    if (category !== "all") {
      countResult = await db.select({ count: sql`count(*)` })
        .from(feedback)
        .where(eq(feedback.category, category));
    }
    
    const totalCount = Number(countResult[0].count);
    
    // Apply sorting
    if (sortBy === "oldest") {
      query = query.orderBy(asc(feedback.timestamp));
    } else {
      // Default is newest first
      query = query.orderBy(desc(feedback.timestamp));
    }
    
    // Calculate pagination
    const offset = (page - 1) * limit;
    query = query.limit(limit).offset(offset);
    
    const feedbacks = await query;
    const pageCount = Math.ceil(totalCount / limit);
    
    return {
      feedbacks,
      totalCount,
      pageCount,
    };
  }
}

// Fall back to in-memory storage if database is not available
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private feedbackItems: Map<number, Feedback>;
  currentUserId: number;
  currentFeedbackId: number;

  constructor() {
    this.users = new Map();
    this.feedbackItems = new Map();
    this.currentUserId = 1;
    this.currentFeedbackId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createFeedback(insertFeedback: InsertFeedback): Promise<Feedback> {
    const id = this.currentFeedbackId++;
    const timestamp = new Date();
    // Make sure category is always a string, defaulting to "general" if it's undefined
    const category = insertFeedback.category || "general";
    const feedback: Feedback = { 
      ...insertFeedback, 
      id, 
      timestamp,
      category 
    };
    this.feedbackItems.set(id, feedback);
    return feedback;
  }

  async getFeedback(
    category: string,
    sortBy: string,
    page: number,
    limit: number
  ): Promise<{
    feedbacks: Feedback[];
    totalCount: number;
    pageCount: number;
  }> {
    let filteredFeedback = Array.from(this.feedbackItems.values());

    // Apply category filter
    if (category !== "all") {
      filteredFeedback = filteredFeedback.filter(
        (item) => item.category === category
      );
    }

    // Apply sorting
    filteredFeedback.sort((a, b) => {
      const dateA = new Date(a.timestamp).getTime();
      const dateB = new Date(b.timestamp).getTime();
      return sortBy === "oldest" ? dateA - dateB : dateB - dateA;
    });

    const totalCount = filteredFeedback.length;
    const pageCount = Math.ceil(totalCount / limit);

    // Apply pagination
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedFeedback = filteredFeedback.slice(startIndex, endIndex);

    return {
      feedbacks: paginatedFeedback,
      totalCount,
      pageCount,
    };
  }
}

// Use DatabaseStorage to connect to PostgreSQL
let storageImpl: IStorage;

try {
  storageImpl = new DatabaseStorage();
  console.log("Using database storage");
} catch (error) {
  console.error("Failed to connect to database, falling back to in-memory storage", error);
  storageImpl = new MemStorage();
}

export const storage = storageImpl;
