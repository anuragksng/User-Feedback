import { useState, useEffect } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import SubmitFeedback from "@/pages/SubmitFeedback";
import FeedbackDashboard from "@/pages/FeedbackDashboard";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

function Router() {
  const [activeTab, setActiveTab] = useState<"submit" | "dashboard">("submit");

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <Header />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab("submit")}
              className={`whitespace-nowrap py-4 px-1 font-medium text-sm ${
                activeTab === "submit"
                  ? "border-primary text-primary border-b-2"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Submit Feedback
            </button>
            <button
              onClick={() => setActiveTab("dashboard")}
              className={`whitespace-nowrap py-4 px-1 font-medium text-sm ${
                activeTab === "dashboard"
                  ? "border-primary text-primary border-b-2"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Feedback Dashboard
            </button>
          </nav>
        </div>
      </div>
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-grow">
        {activeTab === "submit" ? <SubmitFeedback /> : <FeedbackDashboard />}
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
