import { Card, CardContent } from "@/components/ui/card";
import { Feedback } from "@shared/schema";
import { format } from "date-fns";

interface FeedbackCardProps {
  feedback: Feedback;
}

const categoryColors: Record<string, { bg: string; text: string }> = {
  suggestion: { bg: "bg-blue-100", text: "text-blue-500" },
  bug: { bg: "bg-red-100", text: "text-red-500" },
  feature: { bg: "bg-green-100", text: "text-green-500" },
  general: { bg: "bg-amber-100", text: "text-amber-500" },
};

const FeedbackCard = ({ feedback }: FeedbackCardProps) => {
  const { bg, text } = categoryColors[feedback.category] || categoryColors.general;
  
  const formattedDate = format(
    new Date(feedback.timestamp),
    "MMMM d, yyyy"
  );

  return (
    <Card className="overflow-hidden shadow hover:shadow-md transition-shadow duration-300 hover:-translate-y-1 transition-transform">
      <CardContent className="p-0">
        <div className="px-4 py-5 sm:p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="text-xs font-medium text-gray-500">
              <span>{formattedDate}</span>
            </div>
            <span
              className={`px-2 py-1 text-xs font-medium rounded-full ${bg} ${text}`}
            >
              {feedback.category.charAt(0).toUpperCase() + feedback.category.slice(1)}
            </span>
          </div>
          <h3 className="text-lg font-medium text-gray-900">{feedback.name}</h3>
          <p className="text-sm text-gray-500">{feedback.email}</p>
          <p className="mt-3 text-gray-700">{feedback.feedbackText}</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default FeedbackCard;
